$(document).ready(function() {

	// This is your API URL: https://api.adviceslip.com/advice
	
});